/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappyboi;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;

/**
 *
 * @author jakem
 */
public class FlappyBoi extends JPanel implements ActionListener,KeyListener {

    private static final int WINDOW_HEIGHT = 1000;
    private static final int WINDOW_WIDTH = 1000;
    private static final int XPOS = 500;
    private static final int YPOS = 0;
    private static Timer timer;
    private static Bird boi;
    private static int b;
    private static Pipe p;
    private static Pipe p2;
    private static powerUp pUP;
    private static int a;
    private static int pUpPlacement;
    private static int scoreCount;
    private JLabel scoreNum;
    private JLabel titleScreen1;
    private JLabel titleScreen2;
    private JLabel titleScreen3;
    private BufferedImage powerUpImage;
    private JLabel finalPowerUpImage;
    private BufferedImage birdImage;
    private JLabel finalBirdImage;
    private BufferedImage pipeImage;
    private JLabel finalPipeImage;
    private BufferedImage pipeImage2;
    private JLabel finalPipeImage2;
    private String c;
    private BufferedImage pipeImage3;
    private JLabel finalPipeImage3;
    private BufferedImage pipeImage4;
    private JLabel finalPipeImage4;
    private boolean gameRunning;
    private static FlappyBoi game;
    private JFrame gameWindow;
    private JLabel gameOver;
    private JLabel restart;
    private JLabel highScore;
    
    
    public static void main(String[] args) {
    game = new FlappyBoi();
    boi = new Bird();
    game.createAndShowGUI();
    }
    
    FlappyBoi()
    {
        try {
        c = "bb b.png";
            powerUpImage = ImageIO.read(this.getClass().getResource("powerUp.png"));
            finalPowerUpImage = new JLabel(new ImageIcon(powerUpImage));
            birdImage = ImageIO.read(this.getClass().getResource(c));
            finalBirdImage = new JLabel(new ImageIcon(birdImage));
            pipeImage = ImageIO.read(this.getClass().getResource("bottomPipe.png"));
            finalPipeImage = new JLabel(new ImageIcon(pipeImage));
            pipeImage2 = ImageIO.read(this.getClass().getResource("topPipe.png"));
            finalPipeImage2 = new JLabel(new ImageIcon(pipeImage2));
            pipeImage3 = ImageIO.read(this.getClass().getResource("bottomPipe.png"));
            finalPipeImage3 = new JLabel(new ImageIcon(pipeImage3));
            pipeImage4 = ImageIO.read(this.getClass().getResource("topPipe.png"));
            finalPipeImage4 = new JLabel(new ImageIcon(pipeImage4));
            restart = new JLabel("Press R to Restart");
            gameOver = new JLabel("GAME OVER.");
             highScore = new JLabel("Your Score: " + scoreCount);
            timer = new Timer(7,this);
            p = new Pipe(1100);
            p2 = new Pipe(1600);
            a = 90;
            b = 100;
            pUpPlacement = 900+(p2.getXPos()-p.getXPos());
            pUP = new powerUp(pUpPlacement);
            scoreCount = 0;
            scoreNum = new JLabel("0");
            scoreNum.setFont(new Font("Impact",Font.PLAIN,70));
            titleScreen1 = new JLabel("Flappy");
            titleScreen1.setFont(new Font("Impact", Font.PLAIN,120));
            titleScreen1.setBounds(350,250,390,390);
            titleScreen2 = new JLabel("Cardinal");
            titleScreen2.setFont(new Font("Impact", Font.PLAIN,120));
            titleScreen2.setBounds(290,360,500,390);
            titleScreen3 = new JLabel("Press space to start.");
            titleScreen3.setFont(new Font("Impact", Font.PLAIN,40));
            titleScreen3.setBounds(340,480,500,390);
            gameRunning = true;  
        } catch (IOException ex) {
            Logger.getLogger(FlappyBoi.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    public void createAndShowGUI()
    {
    gameWindow = new JFrame("FlappyBoi");
    gameWindow.setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT));
    gameWindow.setLocation(XPOS,YPOS);
    gameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    gameWindow.setContentPane(this);
    gameWindow.addKeyListener(this);
    gameWindow.setLayout(null);
    scoreNum.setBounds(500,20,70,70);
    gameWindow.add(scoreNum);
    gameWindow.add(titleScreen1);
    gameWindow.add(titleScreen2);
    gameWindow.add(titleScreen3);
    finalBirdImage.setBounds(boi.getXPos(),(int)boi.getYPos(), 100, 100);
    gameWindow.add(finalPowerUpImage);
    gameWindow.add(finalBirdImage);
    gameWindow.add(finalPipeImage);
    gameWindow.add(finalPipeImage2);
    gameWindow.add(finalPipeImage3);
    gameWindow.add(finalPipeImage4);
    gameWindow.add(restart);
    gameWindow.add(gameOver);
    gameWindow.add(highScore);
    gameWindow.setResizable(false);
    gameWindow.pack();
    gameWindow.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(boi.getYPos()<860) 
        {
        boi.addGravity(.1);
        boi.setYPos(boi.getYPos() + boi.getGravity());
        }
        else{
        boi.setGravity(0);
        }
        if(p.getXPos() < -100)
        {
        p = null;
        p = new Pipe(p2.getXPos()+600);
        }
        else if(p2.getXPos() < -100)
        {
        p2 = null;
        p2 = new Pipe(p.getXPos()+600);
        }
        
        
        if(gameRunning == true)
        {
        p.decrement();
        p2.decrement();
        pUP.decrement();
        }
        
        finalBirdImage.setBounds(boi.getXPos(),(int)boi.getYPos(),100,100);
        finalPowerUpImage.setBounds(pUP.getXPos(), (int)pUP.getYPos(), 100,b);
        finalPipeImage.setBounds(p.getXPos(),p.getGap() + p.getGapSize(), 100, 750);
        finalPipeImage2.setBounds(p.getXPos(),p.getGap() - 750, 100, 750);
        finalPipeImage3.setBounds(p2.getXPos(),p2.getGap() + p2.getGapSize(), 100, 750);
        finalPipeImage4.setBounds(p2.getXPos(),p2.getGap() - 750, 100, 750);
        
    if((new Rectangle((int)boi.getXPos(),(int)boi.getYPos(),1,(int)boi.getRadius())).intersects(new Rectangle(pUP.getXPos(), pUP.getYPos(),50, 100)))
        {a = 40;
         b = 10000;
         c = "bb b.png";
         }
        
        if((new Rectangle((int)boi.getXPos(),(int)boi.getYPos(),1,(int)boi.getRadius())).intersects(new Rectangle(p.getXPos(),p.getGap(),1,p.getGapSize())))
        {
            scoreCount++;
        }
        if((new Rectangle((int)boi.getXPos(),(int)boi.getYPos(),1,(int)boi.getRadius())).intersects(new Rectangle(p2.getXPos(),p2.getGap(),1,p2.getGapSize())))
        {
            scoreCount++;
        }
        scoreNum.setText(Integer.toString(scoreCount));
        
        if(new Rectangle(boi.getXPos(),(int)boi.getYPos(),boi.getRadius(),boi.getRadius()).intersects(new Rectangle(p.getXPos(),p.getYPos(),p.getWidth(),p.getGap()))
                || (new Rectangle(boi.getXPos(),(int)boi.getYPos(),boi.getRadius(),boi.getRadius()).intersects(new Rectangle(p.getXPos(),p.getGap() + p.getGapSize(),p.getWidth(),p.getGap() + p.getGapSize() + 1000)))
                || (new Rectangle(boi.getXPos(),(int)boi.getYPos(),boi.getRadius(),boi.getRadius()).intersects(new Rectangle(p2.getXPos(),p2.getYPos(),p2.getWidth(),p2.getGap())))
                || (new Rectangle(boi.getXPos(),(int)boi.getYPos(),boi.getRadius(),boi.getRadius()).intersects(new Rectangle(p2.getXPos(),p2.getGap() + p2.getGapSize(),p2.getWidth(),p2.getGap() + p2.getGapSize() + 1000)))
                || (new Rectangle(boi.getXPos(),(int)boi.getYPos(),boi.getRadius(),boi.getRadius()).intersects(new Rectangle(100,0,1,1))))
        {
            gameOver(scoreCount);
        }
        
        validate();
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
    
    }

    @Override
    public void keyPressed(KeyEvent e) {
    if(e.getKeyCode() == KeyEvent.VK_SPACE)
    {
    if(gameRunning == true)
    {
    boi.jump(a);
    boi.setGravity(.5);
    }
    validate();
    repaint();
    timer.start();
    titleScreen1.setBounds(10000,10000,0,0);
    titleScreen2.setBounds(10000,10000,0,0);
    titleScreen3.setBounds(10000,10000,0,0);
    }
    if(e.getKeyCode() == KeyEvent.VK_R)
    {
        if(gameRunning == false)
    {
        restartApplication();
    }
    
        }
    }

    public void restartApplication()
{
    p.setXPos(1100);
    p2.setXPos(1600);
    boi.setYPos(500);
    boi.setGravity(0);
    highScore.setBounds(330,480,10000,10000);
    gameOver.setBounds(330,480,10000,10000);
    restart.setBounds(330,480,10000,10000);
    scoreCount = 0;
    gameRunning = true;
    pUP.setXPos(pUpPlacement);
    a = 90;
    b = 100;
}
    @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    @Override
    public void paintComponent(Graphics g)
    {
    super.paintComponent(g);
    //g.setColor(Color.RED);
    //g.fillOval(boi.getXPos(),(int)boi. (),boi.getRadius(),boi.getRadius());
    
    //g.setColor(Color.GREEN);
    //g.fillRect(p.getXPos(),p.getYPos(),p.getWidth(),p.getGap());
    //g.fillRect(p.getXPos(),p.getGap() + p.getGapSize(),p.getWidth(),p.getGap() + p.getGapSize() + 1000);
    
    //g.fillRect(p2.getXPos(),p2.getYPos(),p2.getWidth(),p2.getGap());
    //g.fillRect(p2.getXPos(),p2.getGap() + p2.getGapSize(),p2.getWidth(),p2.getGap() + p2.getGapSize() + 1000);
    }
    
    public void gameOver(int x)
    {
        gameRunning = false;
        restart.setFont(new Font("Impact", Font.PLAIN,50));
        restart.setBounds(340,600,500,390);
        gameOver.setFont(new Font("Impact", Font.PLAIN,120));
        gameOver.setBounds(250,200,700,390);
        highScore.setFont(new Font("Impact", Font.PLAIN,70));
        highScore.setText("Your Score: " + scoreCount);
        highScore.setBounds(330,480,500,390);
        b = 100;
    }

    
    
}

class Bird{

int radius;
double gravity;
int xPos;
double yPos;

public Bird(){
radius = 100;
gravity = 0;

xPos = 100;
yPos = 500;
}

public double getGravity(){
return gravity;
}

public void addGravity(double x){
gravity += x;
}

public void setGravity(double x){
gravity = x;
}

public int getRadius(){
return radius;
}

public int getXPos(){
return xPos;
}

public double getYPos(){
return yPos;
}

public void enlarge(){
radius+=25;
}

public void shorten(){
radius-=25;
}

public void jump(int x){
yPos -= x;
}


public void setYPos(double x) {
yPos = x; 
}

}

class Pipe{
private int XPos;
private int YPos;
private int width;
private int bottomGap;
private int GAP_SIZE;

Pipe(int x){
    YPos = 0;
    XPos = x;
    width = 100;
    GAP_SIZE = 250;
    bottomGap = (int)(Math.random() * 750);
}

public int getXPos(){
    return XPos;
}
public int getYPos(){
    return YPos;
}
public int getWidth(){
    return width;
}
public int getGap()
{
    return bottomGap;
}
public int getGapSize()
{
    return GAP_SIZE;
}

public void setGapSize(int a)
{
 GAP_SIZE+=a;
}
public void setXPos(int x)
{
    XPos = x;
}
public void decrement()
{
    XPos -= 2;
}
}

class powerUp{ 
private int rarity;
private int duration;
private int XPos;
private int YPos;

powerUp(int a){
YPos = 800;
XPos = a;
rarity = ((int)Math.random()*10);
duration = 50;
}

public int getRarity(){
return rarity;
}

public int getDuration (){
return duration;
}

public void setRarity (int x){
rarity = x;
}

public void setDuration(int x){
duration += x;
}
public int getXPos(){
return XPos;
}

public int getYPos(){
return YPos;
}

public void decrement(){
XPos-=2;
}
public void setXPos(int a){
XPos=a;}
}